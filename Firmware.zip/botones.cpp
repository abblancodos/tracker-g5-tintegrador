

#include <OneButton.h>
#include "keyboard_utils.h"
#include "configuration.h"
#include "board_pinout.h"
#include "button_utils.h"
#include "power_utils.h"
#include "display.h"
#include "sleep_utils.h"


#ifdef BUTTON_PIN

    extern Configuration    Config;
    extern int              menuDisplay;
    extern uint32_t         displayTime;
    extern uint32_t         menuTime;
    extern bool             envio;
    extern bool             beaconmanual;
    extern bool             gpsIsActive;

    namespace BUTTON_Utils {

        OneButton userButton = OneButton(BUTTON_PIN, true, true);

        #ifdef RPC_Electronics_1W_LoRa_GPS
            OneButton userButton2 = OneButton(BUTTON2_PIN, true, true);
            OneButton userButton3 = OneButton(BUTTON3_PIN, true, true);
            OneButton userButton4 = OneButton(BUTTON4_PIN, true, true);
        #endif

        void Presionarboton() {
            envio = true;
            beaconmanual = true;

            if (!gpsIsActive) {
                reposo::gpsWakeUp();
            }

            displayShow("TX", "", "Transmision emergencia", 1000);
        }

        void longPress1() {}
        void doublePress1() {}
        void multiPress1() {}

        void loop() {
            if (!Config.simplifiedTrackerMode) {
                userButton.tick();
                #ifdef RPC_Electronics_1W_LoRa_GPS
                    userButton2.tick();
                    userButton3.tick();
                    userButton4.tick();
                #endif
            }
        }

        void setup() {
            if (!Config.simplifiedTrackerMode) {
                userButton.attachClick(Presionarboton);
                userButton.attachLongPressStart(longPress1);
                userButton.attachDoubleClick(doublePress1);
                userButton.attachMultiClick(multiPress1);
                #ifdef RPC_Electronics_1W_LoRa_GPS
                    userButton2.attachClick(singlePress2);
                    userButton3.attachClick(singlePress3);
                    userButton4.attachClick(singlePress4);
                #endif
            }
        }

    }

#endif